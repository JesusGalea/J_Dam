/**
 * 
 */
/**
 * @author Mañana_posx
 *
 */
module Ejercicio7_p2 {
}