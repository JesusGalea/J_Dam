/**
 * 
 */
/**
 * @author Mañana_posx
 *
 */
module Ejercicio6_p2 {
}