/**
 * 
 */
/**
 * @author Mañana_posx
 *
 */
module Ejercicio1_p2 {
}